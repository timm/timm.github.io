
<img src="img/contactme.jpg" align=right width=200> 
# Contact

**Email:**    
[tim.menzies@gmail.com](mailto:tim.menzies@gmail.com)

**Phone:**    
304-376-2859

**Fax:**     

**Room:**    
3298 EB II [(directions)](https://www.csc.ncsu.edu/department/map/)

**Snail mail:**     
Computer Science, NC State University, 890 Oval Dr, Raleigh, NC, 27695-8206
