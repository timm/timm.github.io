
# Books


<center>

## 2016

<a href="https://www.amazon.com/Perspectives-Data-Science-Software-Engineering/dp/0128042060"><img width=250 src="img/perspectivesBook.jpg"></a>

## 2015

 <a href="https://www.amazon.com/Art-Science-Analyzing-Software-Data/dp/0124115195"><img width=250 src="img/asdbookCover.png"></a>&nbsp;

## 2014

 <a href="https://www.amazon.com/Sharing-Data-Models-Software-Engineering/dp/0124172954"><img width=250 src="img/shareBookCover.png"></a>&nbsp;
 
</center> 

