# Calendar

<iframe src="https://calendar.google.com/calendar/embed?title=Tim%20Menzies%20%28http%3A%2F%2Fmenzies.us%29&amp;mode=AGENDA&amp;height=600&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;src=tim.menzies%40gmail.com&amp;color=%232F6309&amp;src=qhtc59nvho4se0s79k73jcf96c%40group.calendar.google.com&amp;color=%23125A12&amp;src=e54ie3g31nbu77frsagu10pg7o%40group.calendar.google.com&amp;color=%235F6B02&amp;ctz=America%2FNew_York" style="border-width:0" width="470" height="600" frameborder="0" scrolling="no"></iframe>
